// extension.js
const vscode = require("vscode");
const path = require("path");
const fs = require("fs");

function findCliInWorkspace(workspaceFolders) {
  if (!workspaceFolders) return null;
  for (const folder of workspaceFolders) {
    const candidate = path.join(folder.uri.fsPath, "vexon_cli.js");
    if (fs.existsSync(candidate)) return candidate;
  }
  return null;
}

function findCliByWalkingUp(fromPath) {
  if (!fromPath) return null;
  let dir = path.dirname(fromPath);
  const root = path.parse(dir).root;
  while (true) {
    const candidate = path.join(dir, "vexon_cli.js");
    if (fs.existsSync(candidate)) return candidate;
    if (dir === root) break;
    dir = path.dirname(dir);
  }
  return null;
}

function activate(context) {
  const runCommand = vscode.commands.registerCommand("vexon.runFile", async () => {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      vscode.window.showErrorMessage("No active editor to run");
      return;
    }

    const filePath = editor.document.fileName;
    if (!filePath.endsWith(".vx")) {
      vscode.window.showErrorMessage("Active file is not a .vx file");
      return;
    }

    // Try workspace search first
    const folders = vscode.workspace.workspaceFolders || [];
    let cliPath = findCliInWorkspace(folders);

    // Fallback: walk up from file directory
    if (!cliPath) cliPath = findCliByWalkingUp(filePath);

    if (!cliPath) {
      vscode.window.showErrorMessage("Could not find vexon_cli.js in workspace or parent folders. Place vexon_cli.js in your project root.");
      return;
    }

    const termName = "Vexon Runner";
    let terminal = vscode.window.terminals.find(t => t.name === termName);
    if (!terminal) terminal = vscode.window.createTerminal(termName);

    terminal.show(true);

    // Exact command required by you
    const cmd = `node "${cliPath}" run "${filePath}"`;
    terminal.sendText(cmd);
  });

  context.subscriptions.push(runCommand);

  // Status bar Run button
  const status = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
  status.command = "vexon.runFile";
  status.text = "$(play) Run Vexon";
  status.tooltip = "Run current Vexon file (node vexon_cli.js run <file>)";
  status.show();
  context.subscriptions.push(status);

  // Show/hide status based on active editor
  context.subscriptions.push(vscode.window.onDidChangeActiveTextEditor((ed) => {
    if (!ed || !ed.document) { status.hide(); return; }
    if (ed.document.fileName.endsWith(".vx")) status.show();
    else status.hide();
  }));
}

function deactivate() {}

module.exports = { activate, deactivate };
