const vscode = require("vscode");
const path = require("path");

function activate(context) {
  const run = vscode.commands.registerCommand("vexon.runFile", async () => {
    const editor = vscode.window.activeTextEditor;
    if (!editor) return vscode.window.showErrorMessage("No active editor");
    const filePath = editor.document.fileName;
    if (!filePath.endsWith(".vx")) return vscode.window.showErrorMessage("Not a Vexon file");

    // Try to locate vexon_cli.js in the workspace
    const folders = vscode.workspace.workspaceFolders || [];
    const root = folders.length ? folders[0].uri.fsPath : path.dirname(filePath);
    const cliPath = path.join(root, "vexon_cli.js");

    const terminal = vscode.window.createTerminal("Vexon Runner");
    terminal.show();

    // If cli exists in workspace, use it; otherwise just run node on the file
    const fs = require("fs");
    if (fs.existsSync(cliPath)) {
      terminal.sendText(`node "${cliPath}" run "${filePath}"`);
    } else {
      terminal.sendText(`node "${filePath}"`);
    }
  });

  context.subscriptions.push(run);
}

function deactivate() {}
module.exports = { activate, deactivate };
