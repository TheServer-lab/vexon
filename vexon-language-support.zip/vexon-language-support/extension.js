// extension.js
const vscode = require("vscode");
const path = require("path");
const fs = require("fs");

function findCliInWorkspace(workspaceFolders) {
  if (!workspaceFolders) return null;
  for (const folder of workspaceFolders) {
    const candidate = path.join(folder.uri.fsPath, "vexon_cli.js");
    if (fs.existsSync(candidate)) return candidate;
  }
  return null;
}

function findCliByWalkingUp(fromPath) {
  if (!fromPath) return null;
  let dir = path.dirname(fromPath);
  const root = path.parse(dir).root;
  while (true) {
    const candidate = path.join(dir, "vexon_cli.js");
    if (fs.existsSync(candidate)) return candidate;
    if (dir === root) break;
    dir = path.dirname(dir);
  }
  return null;
}

function resolveCliPath(activeFile) {
  // 1) workspace root search
  const folders = vscode.workspace.workspaceFolders || [];
  let cliPath = findCliInWorkspace(folders);

  // 2) walk up from active file
  if (!cliPath) cliPath = findCliByWalkingUp(activeFile);

  // 3) user setting: vexon.cliPath (absolute path)
  try {
    const cfg = vscode.workspace.getConfiguration("vexon");
    const configured = cfg.get("cliPath");
    if (configured && fs.existsSync(configured)) cliPath = configured;
  } catch (e) {
    // ignore config errors
  }

  return cliPath;
}

function runCliCommand(cliPath, filePath, action) {
  const termName = "Vexon Runner";
  let terminal = vscode.window.terminals.find(t => t.name === termName);
  if (!terminal) terminal = vscode.window.createTerminal(termName);
  terminal.show(true);

  // action is "run" or "compile"
  const cmd = `node "${cliPath}" ${action} "${filePath}"`;
  terminal.sendText(cmd);
}

function activate(context) {
  const runCommand = vscode.commands.registerCommand("vexon.runFile", async () => {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      vscode.window.showErrorMessage("No active editor to run");
      return;
    }

    const filePath = editor.document.fileName;
    if (!filePath.endsWith(".vx")) {
      vscode.window.showErrorMessage("Active file is not a .vx file");
      return;
    }

    const cliPath = resolveCliPath(filePath);
    if (!cliPath) {
      vscode.window.showErrorMessage("Could not find vexon_cli.js. Place it in your project root, a parent folder, or set vexon.cliPath in workspace settings.");
      return;
    }

    runCliCommand(cliPath, filePath, "run");
  });

  const compileCommand = vscode.commands.registerCommand("vexon.compileFile", async () => {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      vscode.window.showErrorMessage("No active editor to compile");
      return;
    }

    const filePath = editor.document.fileName;
    if (!filePath.endsWith(".vx")) {
      vscode.window.showErrorMessage("Active file is not a .vx file");
      return;
    }

    const cliPath = resolveCliPath(filePath);
    if (!cliPath) {
      vscode.window.showErrorMessage("Could not find vexon_cli.js. Place it in your project root, a parent folder, or set vexon.cliPath in workspace settings.");
      return;
    }

    runCliCommand(cliPath, filePath, "compile");
  });

  context.subscriptions.push(runCommand, compileCommand);

  // Status bar Run button
  const runStatus = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
  runStatus.command = "vexon.runFile";
  runStatus.text = "$(play) Run Vexon";
  runStatus.tooltip = "Run current Vexon file (node vexon_cli.js run <file>)";
  context.subscriptions.push(runStatus);

  // Status bar Compile button
  const compileStatus = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 99);
  compileStatus.command = "vexon.compileFile";
  compileStatus.text = "$(package) Compile Vexon";
  compileStatus.tooltip = "Compile current Vexon file to EXE (node vexon_cli.js compile <file>)";
  context.subscriptions.push(compileStatus);

  // Show/hide status based on active editor
  function updateStatusVisibility(ed) {
    if (!ed || !ed.document) {
      runStatus.hide();
      compileStatus.hide();
      return;
    }
    if (ed.document.fileName.endsWith(".vx")) {
      runStatus.show();
      compileStatus.show();
    } else {
      runStatus.hide();
      compileStatus.hide();
    }
  }

  updateStatusVisibility(vscode.window.activeTextEditor);
  context.subscriptions.push(vscode.window.onDidChangeActiveTextEditor(updateStatusVisibility));
}

function deactivate() {}

module.exports = { activate, deactivate };
