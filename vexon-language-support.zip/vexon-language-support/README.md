# Vexon Language Support

Minimal VS Code extension for Vexon (.vx) files.

## Features

- Syntax highlighting for Vexon
- Run button in editor title and status bar
- Compile button in editor title and status bar
- Commands:
  - `vexon.runFile` → runs: `node vexon_cli.js run <file>`
  - `vexon.compileFile` → runs: `node vexon_cli.js compile <file>`
- Optional workspace setting `vexon.cliPath` to point to an absolute `vexon_cli.js` path

## Usage

1. Place `vexon_cli.js` in your project root (or a parent folder of the `.vx` file), or set the workspace setting `vexon.cliPath` to the absolute path of your `vexon_cli.js`.
2. Open a `.vx` file.
3. Click the Run or Compile button in the editor title or the status bar, or run the commands from the Command Palette.

## Development

- Install dev dependency:
