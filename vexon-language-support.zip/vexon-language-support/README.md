# Vexon Language Support

Minimal VS Code extension for Vexon (.vx) files.

## Features

- Syntax highlighting for Vexon
- Run button in editor title and status bar
- Command `vexon.runFile` runs: `node vexon_cli.js run <file>`

## Usage

1. Place `vexon_cli.js` in your project root (or a parent folder of the `.vx` file).
2. Open a `.vx` file.
3. Click the Run button in the editor title or the status bar, or run the command `Run Vexon File`.

## Development

- Install dev dependency:
